reformate_subgroup <- function(x) stringr::str_replace_all(x, " |-|/", "_")
