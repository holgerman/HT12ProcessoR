## ------------------------------------------------------------------------
rm(list = ls())
# .libPaths("/mnt/ifs1_projekte/genstat/07_programme/rpackages/forostar/")


require(rmarkdown)
require(lumi)
require(ggplot2)
require(data.table)
require(knitr)
require(pander)
panderOptions('table.split.table', Inf)

require(HT12ProcessoR) 


knitr::opts_chunk$set(cache = FALSE, results = "markup", echo=T , fig.width = 9, fig.height = 6, eval = TRUE)

options(stringsAsFactors=FALSE)

## ------------------------------------------------------------------------

datadirectory = path.package("HT12ProcessoR")
# datadirectory = '/mnt/ifs1_projekte/genstat/07_programme/rtools/HT12ProcessoR/inst/'

# input = data.table(fileset_id = c('f2226-2270', '334-2184'),
# con_f = c(paste0(datadirectory,"/ControlProbeProfile_2226-2270.txt"),paste0(datadirectory,"/ControlProbeProfile_334-2184.txt")),
# nobkgd_f = c(paste0(datadirectory,"/Einzelanalyse_nonorm_nobkgd_2226-2270.txt"),paste0(datadirectory,"/Einzelanalyse_nonorm_nobkgd_334-2184.txt")),
# sample_f = c(paste0(datadirectory,"/SamplesTable_2226-2270.txt"),paste0(datadirectory,"/SamplesTable_334-2184.txt")))

 input = data.table(fileset_id = c('f34-21', '334-2184'), 
                     con_f = c(paste0(datadirectory,"/Run12_ControlProbeProfile_590-651.txt"),paste0(datadirectory,"/ControlProbeProfile_HSS106-HSS155.txt")),
                     nobkgd_f = c(paste0(datadirectory,"/Run12_nonorm_nobkgd_590-651.txt"),paste0(datadirectory,"/Einzelanalyse_nonorm_nobkgd_HSS106-HSS155.txt")),
                     sample_f = c(paste0(datadirectory,"/Run12_SamplesTable_590-651.txt"),paste0(datadirectory,"/SamplesTable_HSS106-HSS155.txt")))


prepro_folder = "R:/genstat/07_programme/rtools/HT12ProcessoR/_archive/example2"
dir.create(prepro_folder)

input_filename = paste0(prepro_folder, "/s01a_file_overview.txt")

write.table(input,input_filename ,quote=F, col.names=T, row.names=F, sep="\t")


## ------------------------------------------------------------------------
myparams = read.delim(paste0(datadirectory, "/input_parameter_010.txt"), as.is = T)


## ------------------------------------------------------------------------

myparams[ myparams$variable == "file_names_of_files_and_folders", "value"] = input_filename
myparams[ myparams$variable == "datafolder_results", "value"] = paste0(prepro_folder, "/tosent/")

myparams[ myparams$variable == "file_renaming_samples_tosent", "value"] = paste0(prepro_folder, "/tosent/")


myparamfile = paste0(prepro_folder, "/input_parameter_010.txt")
write.table(myparams,myparamfile ,quote=F, col.names=T, row.names=F, sep="\t")


## ------------------------------------------------------------------------

prepro_ht12 = checkExtractChipsamples(paramfile =myparamfile)

pander(prepro_ht12$history)
class(prepro_ht12)

pander(ht(prepro_ht12$chipsamples,1))


## ------------------------------------------------------------------------
ht(prepro_ht12$chipsamples,2)


## Exclude Samples

prepro_ht12$chipsamples = prepro_ht12$chipsamples[ ! prepro_ht12$chipsamples$old_ID  %in%  c("614", "638", "HSS 108", "HSS 112", "HSS 115", "HSS 125", "HSS 127", "HSS 133", "HSS 137", "HSS 138", "HSS 146", "HSS 151","HSS 155"),]
## Define Subgroups
prepro_ht12$chipsamples$subgroup = "PBMC"
table(prepro_ht12$chipsamples$subgroup)

xtabs(~prepro_ht12$chipsamples$Sentrix.Barcode + prepro_ht12$chipsamples$processingbatch)

xtabs(~prepro_ht12$chipsamples$strangebatch + prepro_ht12$chipsamples$processingbatch)


## Quick Check for major differences based on Attributes from the provided ILLUMINA-sample-files
initial_pca = calcInitialPCA(prepro_ht12)

p1 = ggplot(initial_pca$scores, aes(Comp.1, Comp.2, pch = subgroup , col = processingbatch , size = Detected.Genes..0.01., alpha = in_study)) + geom_point() + scale_alpha_manual(values = c(0.7, 0.3))
p1


## ------------------------------------------------------------------------
prepro_ht12 = createExpressionSet(prepro_ht12, paramfile = myparamfile)

## Have a look:
kable(prepro_ht12$history)
prepro_ht12$all_nobkgd_eset
hh(prepro_ht12$rawdataWOcons_joined)
hh(detection(prepro_ht12$all_nobkgd_eset))

prepro_ht12$total_nobkgd_eset
hh(prepro_ht12$rawdataOnlycons_joined)
hh(detection(prepro_ht12$total_nobkgd_eset))


## ------------------------------------------------------------------------
prepro_ht12 = filterLowExpressed(prepro_ht12, paramfile = myparamfile)
kable(prepro_ht12$history)

head(prepro_ht12$genesdetail)
setDT(prepro_ht12$chipsamples)
prepro_ht12$chipsamples[,.N,.(in_study, reason4exclusion)]

setDF(prepro_ht12$chipsamples)


## ------------------------------------------------------------------------
prepro_ht12 = transformNormalizeHT12object(prepro_ht12, paramfile = myparamfile)

prepro_ht12 = filterTechnicallyFailed(prepro_ht12, paramfile = myparamfile)
kable(prepro_ht12$history)

## ------------------------------------------------------------------------

prepro_ht12 = filter4MinBatchsize(prepro_ht12, paramfile = myparamfile)


prepro_ht12 = transformNormalizeHT12object(prepro_ht12, paramfile = myparamfile) ## only necessary if samples were removed in previous step

prepro_ht12 = removeBatchEffects(prepro_ht12, paramfile = myparamfile)
kable(prepro_ht12$history)


## ------------------------------------------------------------------------
prepro_ht12 = checkBatchEffects(prepro_ht12, paramfile = myparamfile)
ht(prepro_ht12$genesdetail,2)
kable(prepro_ht12$history)

## ------------------------------------------------------------------------
prepro_ht12 = filterAtypicalExpressed(prepro_ht12, paramfile = myparamfile)
ht(prepro_ht12$chipsamples,2)
kable(prepro_ht12$history)

## ------------------------------------------------------------------------

prepro_ht12 = visualizePreprocessing(prepro_ht12, paramfile = myparamfile)

prepro_ht12 = comparePCBeforeAfterPrePro(prepro_ht12, paramfile = myparamfile)
kable(prepro_ht12$history)

## ------------------------------------------------------------------------
## Set parameter to use provided renaming file
renaming_fn = paste0(datadirectory, "/renamingsamples.txt")
myparams[ myparams$variable == "file_renaming_samples_tosent", "value"] = renaming_fn
write.table(myparams,myparamfile ,quote=F, col.names=T, row.names=F, sep="\t")

prepro_ht12 = writeFilesTosent(prepro_ht12, paramfile = myparamfile)
ht(prepro_ht12$chipsamples,1)
prepro_ht12$history


## ------------------------------------------------------------------------
save(prepro_ht12, file = paste0(prepro_folder,"/prepro_example1_HT12object.RData"))


## ----results="asis"------------------------------------------------------
mm_text = createTextForMethods(prepro_ht12, paramfile = myparamfile)
cat('### Extended Version')
cat(mm_text$extended_version)
cat('### Short Version')
cat(mm_text$short_version)

## ----sesionifno, results='markup'----------------------------------------
sessionInfo()

